#pragma once

#include "Vector.h"
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>

namespace ManejoVectorForm {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	//variable global
	Vector vectorsito;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNota;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnInsertar;
	private: System::Windows::Forms::Button^  btnEliminar;
	private: System::Windows::Forms::DataGridView^  grillavector;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
		this->label1 = (gcnew System::Windows::Forms::Label());
		this->label2 = (gcnew System::Windows::Forms::Label());
		this->txtTamano = (gcnew System::Windows::Forms::TextBox());
		this->txtNota = (gcnew System::Windows::Forms::TextBox());
		this->btnDefinir = (gcnew System::Windows::Forms::Button());
		this->btnInsertar = (gcnew System::Windows::Forms::Button());
		this->btnEliminar = (gcnew System::Windows::Forms::Button());
		this->grillavector = (gcnew System::Windows::Forms::DataGridView());
		this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillavector))->BeginInit();
		this->SuspendLayout();
		// 
		// label1
		// 
		this->label1->AutoSize = true;
		this->label1->Location = System::Drawing::Point(13, 40);
		this->label1->Name = L"label1";
		this->label1->Size = System::Drawing::Size(60, 17);
		this->label1->TabIndex = 0;
		this->label1->Text = L"Tama�o";
		// 
		// label2
		// 
		this->label2->AutoSize = true;
		this->label2->Location = System::Drawing::Point(16, 91);
		this->label2->Name = L"label2";
		this->label2->Size = System::Drawing::Size(38, 17);
		this->label2->TabIndex = 1;
		this->label2->Text = L"Nota";
		// 
		// txtTamano
		// 
		this->txtTamano->Location = System::Drawing::Point(122, 40);
		this->txtTamano->Name = L"txtTamano";
		this->txtTamano->Size = System::Drawing::Size(100, 22);
		this->txtTamano->TabIndex = 2;
		// 
		// txtNota
		// 
		this->txtNota->Location = System::Drawing::Point(122, 91);
		this->txtNota->Name = L"txtNota";
		this->txtNota->Size = System::Drawing::Size(100, 22);
		this->txtNota->TabIndex = 3;
		// 
		// btnDefinir
		// 
		this->btnDefinir->Location = System::Drawing::Point(266, 40);
		this->btnDefinir->Name = L"btnDefinir";
		this->btnDefinir->Size = System::Drawing::Size(75, 23);
		this->btnDefinir->TabIndex = 4;
		this->btnDefinir->Text = L"Definir";
		this->btnDefinir->UseVisualStyleBackColor = true;
		this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
		// 
		// btnInsertar
		// 
		this->btnInsertar->Location = System::Drawing::Point(266, 88);
		this->btnInsertar->Name = L"btnInsertar";
		this->btnInsertar->Size = System::Drawing::Size(75, 23);
		this->btnInsertar->TabIndex = 5;
		this->btnInsertar->Text = L"Insertar";
		this->btnInsertar->UseVisualStyleBackColor = true;
		this->btnInsertar->Click += gcnew System::EventHandler(this, &Form1::btnInsertar_Click);
		// 
		// btnEliminar
		// 
		this->btnEliminar->Location = System::Drawing::Point(266, 130);
		this->btnEliminar->Name = L"btnEliminar";
		this->btnEliminar->Size = System::Drawing::Size(75, 23);
		this->btnEliminar->TabIndex = 6;
		this->btnEliminar->Text = L"Eliminar";
		this->btnEliminar->UseVisualStyleBackColor = true;
		this->btnEliminar->Click += gcnew System::EventHandler(this, &Form1::btnEliminar_Click);
		// 
		// grillavector
		// 
		this->grillavector->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
		this->grillavector->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
		this->grillavector->Location = System::Drawing::Point(31, 168);
		this->grillavector->Name = L"grillavector";
		this->grillavector->RowTemplate->Height = 24;
		this->grillavector->Size = System::Drawing::Size(240, 150);
		this->grillavector->TabIndex = 7;
		this->grillavector->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellContentClick);
		// 
		// Column1
		// 
		this->Column1->HeaderText = L"Nota";
		this->Column1->Name = L"Column1";
		// 
		// Form1
		// 
		this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
		this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
		this->ClientSize = System::Drawing::Size(353, 335);
		this->Controls->Add(this->grillavector);
		this->Controls->Add(this->btnEliminar);
		this->Controls->Add(this->btnInsertar);
		this->Controls->Add(this->btnDefinir);
		this->Controls->Add(this->txtNota);
		this->Controls->Add(this->txtTamano);
		this->Controls->Add(this->label2);
		this->Controls->Add(this->label1);
		this->Name = L"Form1";
		this->Text = L"Form1";
		(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillavector))->EndInit();
		this->ResumeLayout(false);
		this->PerformLayout();

			}
#pragma endregion
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			int tam;
			tam=System::Convert::ToInt32(txtTamano->Text);
			vectorsito.Set_tamano(tam);
			grillavector->RowCount=vectorsito.Get_tamano();
			pos=0;
		 }
private: System::Void btnInsertar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elemento;
			 elemento=System::Convert::ToInt32(txtNota->Text);
			 if(vectorsito.Insertar(elemento,pos))
			  {
				pos++;
				//Despliegue del vector
				grillavector->ColumnCount=1;
				grillavector->RowCount=vectorsito.Get_tamano();
				int nota;
				for(int i=0; i<vectorsito.Get_tamano(); i++)
				 {
					nota=vectorsito.Get_vector(i);
					grillavector->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(nota);
				 }
			  }
			 }
private: System::Void btnEliminar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elemento;
			 elemento=System::Convert::ToInt32(txtNota->Text);
			 if(vectorsito.Eliminar(elemento))
			  {
				//despliegue del vector
			  grillavector->ColumnCount=1;
			  pos--;
			  if(grillavector->RowCount==1)
			   {
				grillavector->Rows[0]->Cells[0]->Value="";
			   }
			  else
			   {
				grillavector->RowCount=vectorsito.Get_tamano();
				int nota;
				for(int i=0; i<vectorsito.Get_tamano(); i++)
				 {
					nota=vectorsito.Get_vector(i);
					grillavector->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(nota);
				 }
			   }
			  }
			 else
			  {
				MessageBox::Show("No existe el dato");
			  }
			 }
};
}

