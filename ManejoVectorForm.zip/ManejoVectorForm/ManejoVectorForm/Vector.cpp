#include "StdAfx.h"
#include "Vector.h"
#define MAX 10


Vector::Vector(void)
{
	vec[MAX]=0;
	tamano=0;
}

Vector::~Vector(void)
{
}

int Vector::Get_tamano()
{
	return tamano;
}

void Vector::Set_tamano(int tam)
{
	tamano=tam;
}

int Vector::Get_vector(int posicion)
{
	return vec[posicion];
}

void Vector::Set_vector(int posicion, int _elem)
{
	vec[posicion]=_elem;
}

void Vector::Incrementar()
{
	tamano++;
}

void Vector::Decrementar()
{
	tamano--;		//tamano=tamano-1
}
	
bool Vector::Vacio_vector()
{
	if (tamano==0)
	 {
		return true;
	 }
	else
	{
		return false;
	}
}

bool Vector::Lleno_vector()
{
	if(tamano==MAX)
	{
		return true;
	}
	else
	{
		return false;
	}
}
	
bool Vector::Insertar(int _elemento, int posicion)
{
	if((posicion<0)&&(posicion>tamano))
		return false;
	else
	{
		if(Lleno_vector()==true)
		{
			return false;
		}
		else
		{
			int i=Get_tamano();
			while(i>posicion)
			{
				vec[i]=vec[i-1];
				i--;
			}
			vec[posicion]=_elemento;
			//incrementar();
			return true;
		}
	}
}

bool Vector::Eliminar(int _elemento)
{
	int pos=0, i=0;
	if(Vacio_vector()==true)
	{
		return false;
	}
	else
	{
		if (Buscar(_elemento,pos))
		{
			i=pos;
			while(i<Get_tamano())
			{
				vec[i]=vec[i+1];
				i++;
			}
			Decrementar();
			return true;
		}
	}
}
	
bool Vector::Buscar(int elem, int &posicion)
{
	for(int i=0; i<tamano; i++)
	{
		if(vec[i]==elem)
		{
			posicion=i;
			return true;
		}
	}
	return false;
}